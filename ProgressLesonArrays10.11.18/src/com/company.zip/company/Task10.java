package com.company;

public class Task10 {
}
